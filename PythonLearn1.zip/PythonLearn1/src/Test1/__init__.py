#导入工具库
import operator
import pandas as pd
import numpy as np
import statsmodels.api as sm
import scipy.stats as stats
import matplotlib.pyplot as plt
import matplotlib

#数据预处理成cvs格式
fp_origin = open("./Analysis.txt", 'r')
fp_modified = open("./Analysis.csv", 'w')

line = fp_origin.readline()
while(line):
    temp = line.strip().split()
    #print(temp)
    temp = ','.join(temp)+'\n'
    #print(temp)
    fp_modified.write(temp)
    line = fp_origin.readline()
    
fp_origin.close()
fp_modified.close()

#定义数据属性变量名
name_category = ["season", "river_size", "river_speed"]
name_value = ["mxPH", "mnO2", "Cl", "NO3", "NH4", "oPO4", "PO4", "Chla", "a1", "a2", "a3", "a4", "a5", "a6", "a7"]
name_seaweed = ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]

#将数据读入程序
data_origin = pd.read_csv("./Analysis.csv", 
                   names = name_category+name_value,
                   na_values = "XXXXXXX")
#print(data_origin)

#对于标称属性统计频数
for item in name_category:
    print(item, '的频数为：\n', pd.value_counts(data_origin[item].values), '\n')

#对于数值属性显示其详细信息    
print(data_origin[name_value].describe())

# 直方图
fig = plt.figure(figsize = (20,20))
i = 1
for item in name_value:
    ax = fig.add_subplot(5, 3, i)
    data_origin[item].plot(kind = 'hist', title = item, ax = ax)
    i += 1
plt.subplots_adjust(wspace = 0.2, hspace = 0.2)
fig.savefig('./image/直方图.png')

# qq图
fig = plt.figure(figsize = (20,20))
i = 1
for item in name_value:
    ax = fig.add_subplot(5, 3, i)
    sm.qqplot(data_origin[item], ax = ax)
    ax.set_title(item)
    i += 1
plt.subplots_adjust(wspace = 0.3, hspace = 0.3)
fig.savefig('./image/qq图.png')

# 盒图
fig = plt.figure(figsize = (20,20))
i = 1
for item in name_value:
    ax = fig.add_subplot(5, 3, i)
    data_origin[item].plot(kind = 'box')
    i += 1
fig.savefig('./image/盒图.png')

# 条件盒图
fig = plt.figure(figsize = (10, 27))
i = 1
for seaweed in name_seaweed:
    for category in name_category:
        ax = fig.add_subplot(7, 3, i)
        data_origin[[seaweed, category]].boxplot(by = category, ax = ax)
        ax.set_title(seaweed)
        i += 1
plt.subplots_adjust(hspace = 0.5, wspace = 0.3)
fig.savefig('./image/条件盒图.png')

#缺失索引
nan_list = pd.isnull(data_origin).any(1).nonzero()[0]
#print(nan_list)

#将缺失部分剔除
data_filtrated = data_origin.dropna()
data_filtrated.to_csv('./data/delete.csv', mode = 'w', encoding='utf-8', index = False,header = False)

#用最高频率值来填补缺失值
data_filtrated = data_origin.copy()
for item in name_category+name_value:
    # 计算最高频率的值
    most_frequent_value = data_filtrated[item].value_counts().idxmax()
    # 替换缺失值
    data_filtrated[item].fillna(value = most_frequent_value, inplace = True)
data_filtrated.to_csv('./data/most.csv', mode = 'w', encoding='utf-8', index = False,header = False)   

#通过属性的相关关系来填补缺失值
data_filtrated = data_origin.copy()
for item in name_value:
    data_filtrated[item].interpolate(inplace = True)
data_filtrated.to_csv('./data/corelation.csv', mode = 'w', encoding='utf-8', index = False,header = False)

# 通过数据对象之间的相似性来填补缺失值   
data_norm = data_origin.copy()
data_norm[name_value] = data_norm[name_value].fillna(0)
data_norm[name_value] = data_norm[name_value].apply(lambda x : (x - np.mean(x)) / (np.max(x) - np.min(x)))
score = {}
range_length = len(data_origin)
for i in range(0, range_length):
    score[i] = {}
    for j in range(0, range_length):
        score[i][j] = 0  
for i in range(0, range_length):
    for j in range(i, range_length):
        for item in name_category:
            if data_norm.iloc[i][item] != data_norm.iloc[j][item]:
                score[i][j] += 1
        for item in name_value:
            temp = abs(data_norm.iloc[i][item] - data_norm.iloc[j][item])
            score[i][j] += temp
        score[j][i] = score[i][j]
data_filtrated = data_origin.copy()
for index in nan_list:
    best_friend = sorted(score[index].items(), key=operator.itemgetter(1), reverse = False)[1][0]
    for item in name_value:
        if pd.isnull(data_filtrated.iloc[index][item]):
            if pd.isnull(data_origin.iloc[best_friend][item]):
                data_filtrated.ix[index, item] = data_origin[item].value_counts().idxmax()
            else:
                data_filtrated.ix[index, item] = data_origin.iloc[best_friend][item]
data_filtrated.to_csv('./data/similarity.csv', mode = 'w', encoding='utf-8', index = False,header = False)
print('finished')